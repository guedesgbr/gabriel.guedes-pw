CREATE DATABASE projeto;

USE projeto;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL
);
SELECT * FROM usuarios;
INSERT INTO usuarios (login, senha)
VALUES ('admin', '123456');
SELECT * FROM usuarios;
USE projeto;

CREATE TABLE funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    funcao VARCHAR(100) NOT NULL,
    salario DECIMAL(10,2) NOT NULL
);

SELECT * FROM funcionarios;
USE projeto;

SELECT * FROM funcionarios;