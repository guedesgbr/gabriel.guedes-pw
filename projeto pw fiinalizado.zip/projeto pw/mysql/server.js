
const express = require("express");
const mysql = require("mysql2");
const path = require("path");

const app = express();

const pastaVscode = path.join(__dirname, "..", "vscode");

console.log("Pasta dos arquivos:", pastaVscode);

app.use(express.json());
app.use(express.static(pastaVscode));

app.get("/", function(req, res) {
    res.sendFile(path.join(pastaVscode, "index.html"));
});

const banco = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "projeto"
});

banco.connect(function(erro) {
    if (erro) {
        console.log("Erro ao conectar ao MySQL:", erro);
        return;
    }

    console.log("Conectado ao MySQL!");
});

// LOGIN

app.post("/api/login", function(req, res) {
    const login = req.body.login;
    const senha = req.body.senha;

    if (!login || !senha) {
        return res.status(400).json({
            success: false
        });
    }

    const sql = "SELECT * FROM usuarios WHERE login = ? AND senha = ?";

    banco.query(sql, [login, senha], function(erro, resultados) {
        if (erro) {
            console.log("Erro na consulta:", erro);

            return res.status(500).json({
                success: false
            });
        }

        if (resultados.length > 0) {
            return res.json({
                success: true
            });
        }

        res.status(401).json({
            success: false
        });
    });
});

// CADASTRAR FUNCIONÁRIOS

app.post("/api/funcionarios", function(req, res) {
    const nome = req.body.nome;
    const funcao = req.body.funcao;
    const salario = req.body.salario;

    if (!nome || !funcao || salario === undefined || salario === "") {
        return res.status(400).json({
            sucesso: false,
            mensagem: "Preencha todos os campos."
        });
    }

    const sql = "INSERT INTO funcionarios (nome, funcao, salario) VALUES (?, ?, ?)";

    banco.query(sql, [nome, funcao, salario], function(erro, resultado) {
        if (erro) {
            console.log("Erro ao cadastrar funcionário:", erro);

            return res.status(500).json({
                sucesso: false
            });
        }

        res.json({
            sucesso: true,
            mensagem: "Funcionário cadastrado!"
        });
    });
});

// CONSULTAR FUNCIONÁRIOS

app.get("/api/funcionarios", function(req, res) {
    const sql = "SELECT * FROM funcionarios";

    banco.query(sql, function(erro, resultados) {
        if (erro) {
            console.log("Erro ao consultar funcionários:", erro);

            return res.status(500).json([]);
        }

        res.json(resultados);
    });
});

// INICIAR SERVIDOR

app.listen(3000, function() {
    console.log("Servidor rodando na porta 3000!");
});
