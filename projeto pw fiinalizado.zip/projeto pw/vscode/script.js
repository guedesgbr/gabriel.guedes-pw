
// LOGIN

const formulario = document.getElementById("formLogin");

if (formulario) {
    formulario.addEventListener("submit", async function(event) {
        event.preventDefault();

        const login = document.getElementById("login").value;
        const senha = document.getElementById("senha").value;
        const mensagem = document.getElementById("mensagem");

        try {
            const resposta = await fetch("/api/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    login: login,
                    senha: senha
                })
            });

            const dados = await resposta.json();

            if (resposta.ok && dados.success) {
                localStorage.setItem("logado", "true");
                window.location.href = "area.html";
            } else {
                mensagem.textContent = "Usuário ou senha incorretos.";
            }

        } catch (erro) {
            mensagem.textContent = "Erro ao conectar com o servidor.";
            console.log(erro);
        }
    });
}

// CADASTRO DE FUNCIONÁRIOS

const modal = document.querySelector(".modal-container");
const formularioCadastro = document.getElementById("formCadastro");
const tabela = document.querySelector("tbody");
const mensagemVazia = document.getElementById("mensagemVazia");

let funcionarios = [];
let indiceEdicao = null;

function openModal() {
    modal.classList.add("active");
}

function closeModal() {
    modal.classList.remove("active");
    formularioCadastro.reset();
    indiceEdicao = null;
}

async function carregarFuncionarios() {
    try {
        const resposta = await fetch("/api/funcionarios");
        funcionarios = await resposta.json();
        atualizarTabela();
    } catch (erro) {
        console.log("Erro ao carregar funcionários:", erro);
    }
}

if (formularioCadastro) {
    formularioCadastro.addEventListener("submit", async function(event) {
        event.preventDefault();

        const nome = document.getElementById("m-nome").value;
        const funcao = document.getElementById("m-funcao").value;
        const salario = document.getElementById("m-salario").value;

        const funcionario = {
            nome: nome,
            funcao: funcao,
            salario: salario
        };

        try {
            if (indiceEdicao === null) {
                const resposta = await fetch("/api/funcionarios", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(funcionario)
                });

                const dados = await resposta.json();

                if (!resposta.ok || !dados.sucesso) {
                    alert("Erro ao cadastrar funcionário.");
                    return;
                }
            } else {
                alert("A edição no MySQL será implementada na próxima etapa.");
                return;
            }

            await carregarFuncionarios();
            closeModal();

        } catch (erro) {
            alert("Não foi possível conectar ao servidor.");
        }
    });

    carregarFuncionarios();
}

function atualizarTabela() {
    tabela.innerHTML = "";

    if (mensagemVazia) {
        mensagemVazia.style.display = funcionarios.length === 0 ? "block" : "none";
    }

    funcionarios.forEach(function(funcionario, indice) {
        const linha = document.createElement("tr");

        linha.innerHTML = `
            <td>${funcionario.nome}</td>
            <td>${funcionario.funcao}</td>
            <td>R$ ${Number(funcionario.salario).toFixed(2)}</td>
            <td class="acao">
                <button type="button" onclick="editarFuncionario(${indice})">
                    <i class='bx bx-edit'></i>
                </button>
            </td>
            <td class="acao">
                <button type="button" onclick="excluirFuncionario(${indice})">
                    <i class='bx bx-trash'></i>
                </button>
            </td>
        `;

        tabela.appendChild(linha);
    });
}

function editarFuncionario(indice) {
    const funcionario = funcionarios[indice];

    document.getElementById("m-nome").value = funcionario.nome;
    document.getElementById("m-funcao").value = funcionario.funcao;
    document.getElementById("m-salario").value = funcionario.salario;

    indiceEdicao = indice;
    openModal();
}

function excluirFuncionario(indice) {
    alert("A exclusão no MySQL será implementada na próxima etapa.");
}

function sair() {
    localStorage.removeItem("logado");
    window.location.href = "index.html";
}
