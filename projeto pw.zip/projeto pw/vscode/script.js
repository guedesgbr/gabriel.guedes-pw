
const formulario = document.getElementById("formLogin");

formulario.addEventListener("submit", async function(event) {
    event.preventDefault();

    const login = document.getElementById("login").value;
    const senha = document.getElementById("senha").value;
    const mensagem = document.getElementById("mensagem");

    try {
        const resposta = await fetch("/api/login", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                login: login,
                senha: senha
            })
        });

        const dados = await resposta.json();

        if (resposta.ok && dados.success) {
            localStorage.setItem("logado", "true");
            window.location.href = "area.html";
        } else {
            mensagem.textContent = "Usuário ou senha incorretos.";
        }

    } catch (erro) {
        mensagem.textContent = "Erro ao conectar com o servidor.";
    }
});
