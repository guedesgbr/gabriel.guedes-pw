
const express = require("express");
const mysql = require("mysql2");
const path = require("path");

const app = express();

const pastaVscode = path.join(__dirname, "..", "vscode");

console.log("Pasta dos arquivos:", pastaVscode);

app.use(express.json());
app.use(express.static(pastaVscode));

app.get("/", function(req, res) {
    res.sendFile(path.join(pastaVscode, "index.html"));
});

const banco = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "projeto"
});

banco.connect(function(erro) {
    if (erro) {
        console.log("Erro ao conectar ao MySQL:", erro);
        return;
    }

    console.log("Conectado ao MySQL!");
});

app.post("/api/login", function(req, res) {
    const login = req.body.login;
    const senha = req.body.senha;

    if (!login || !senha) {
        return res.status(400).json({
            success: false
        });
    }

    const sql = "SELECT * FROM usuarios WHERE login = ? AND senha = ?";

    banco.query(sql, [login, senha], function(erro, resultados) {
        if (erro) {
            console.log("Erro na consulta:", erro);

            return res.status(500).json({
                success: false
            });
        }

        if (resultados.length > 0) {
            return res.json({
                success: true
            });
        }

        res.status(401).json({
            success: false
        });
    });
});

app.listen(3000, function() {
    console.log("Servidor rodando na porta 3000!");
});
